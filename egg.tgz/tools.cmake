# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(larch src/larch.cpp)
set_property(TARGET larch PROPERTY CXX_STANDARD 11)
target_link_libraries(larch lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(noise_contour src/noise_contour.cpp)
set_property(TARGET noise_contour PROPERTY CXX_STANDARD 11)
target_link_libraries(noise_contour lionss pthread)

add_executable(saffron src/saffron.cpp)
set_property(TARGET saffron PROPERTY CXX_STANDARD 11)
target_link_libraries(saffron lionss pthread)

add_executable(sedge src/sedge.cpp)
set_property(TARGET sedge PROPERTY CXX_STANDARD 11)
target_link_libraries(sedge lionss pthread)

add_executable(logchew src/logchew.cpp)
set_property(TARGET logchew PROPERTY CXX_STANDARD 11)
target_link_libraries(logchew lionss pthread)

add_executable(TelemRollup src/TelemRollup.cpp)
set_property(TARGET TelemRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(TelemRollup lionss pthread)

add_executable(keelcad src/keelcad.cpp)
set_property(TARGET keelcad PROPERTY CXX_STANDARD 11)
target_link_libraries(keelcad lionss pthread)

add_executable(ttsChildVoice src/ttsChildVoice.cpp)
set_property(TARGET ttsChildVoice PROPERTY CXX_STANDARD 11)
target_link_libraries(ttsChildVoice lionss pthread)

add_executable(kelp src/kelp.cpp)
set_property(TARGET kelp PROPERTY CXX_STANDARD 11)
target_link_libraries(kelp lionss pthread)

add_executable(xcompile-riscv src/xcompile-riscv.cpp)
set_property(TARGET xcompile-riscv PROPERTY CXX_STANDARD 11)
target_link_libraries(xcompile-riscv lionss pthread)

add_executable(mri_cs_recon src/mri_cs_recon.cpp)
set_property(TARGET mri_cs_recon PROPERTY CXX_STANDARD 11)
target_link_libraries(mri_cs_recon lionss pthread)

add_executable(loomsong src/loomsong.cpp)
set_property(TARGET loomsong PROPERTY CXX_STANDARD 11)
target_link_libraries(loomsong lionss pthread)

add_executable(cache_stampede src/cache_stampede.cpp)
set_property(TARGET cache_stampede PROPERTY CXX_STANDARD 11)
target_link_libraries(cache_stampede lionss pthread)

add_executable(antennaDipole src/antennaDipole.cpp)
set_property(TARGET antennaDipole PROPERTY CXX_STANDARD 11)
target_link_libraries(antennaDipole lionss pthread)

add_executable(libwave_fft src/libwave_fft.cpp)
set_property(TARGET libwave_fft PROPERTY CXX_STANDARD 11)
target_link_libraries(libwave_fft lionss pthread)

add_executable(vesper src/vesper.cpp)
set_property(TARGET vesper PROPERTY CXX_STANDARD 11)
target_link_libraries(vesper lionss pthread)

add_executable(BleMeshTtl src/BleMeshTtl.cpp)
set_property(TARGET BleMeshTtl PROPERTY CXX_STANDARD 11)
target_link_libraries(BleMeshTtl lionss pthread)

add_executable(promolift src/promolift.cpp)
set_property(TARGET promolift PROPERTY CXX_STANDARD 11)
target_link_libraries(promolift lionss pthread)

add_executable(CustomsHs src/CustomsHs.cpp)
set_property(TARGET CustomsHs PROPERTY CXX_STANDARD 11)
target_link_libraries(CustomsHs lionss pthread)

add_executable(foldtiny src/foldtiny.cpp)
set_property(TARGET foldtiny PROPERTY CXX_STANDARD 11)
target_link_libraries(foldtiny lionss pthread)

add_executable(lca-bottle src/lca-bottle.cpp)
set_property(TARGET lca-bottle PROPERTY CXX_STANDARD 11)
target_link_libraries(lca-bottle lionss pthread)

add_executable(BarleyYield src/BarleyYield.cpp)
set_property(TARGET BarleyYield PROPERTY CXX_STANDARD 11)
target_link_libraries(BarleyYield lionss pthread)

add_executable(proj_lantern src/proj_lantern.cpp)
set_property(TARGET proj_lantern PROPERTY CXX_STANDARD 11)
target_link_libraries(proj_lantern lionss pthread)

add_executable(monorepo-affected src/monorepo-affected.cpp)
set_property(TARGET monorepo-affected PROPERTY CXX_STANDARD 11)
target_link_libraries(monorepo-affected lionss pthread)

add_executable(glacierMelt2k src/glacierMelt2k.cpp)
set_property(TARGET glacierMelt2k PROPERTY CXX_STANDARD 11)
target_link_libraries(glacierMelt2k lionss pthread)

add_executable(harptuner src/harptuner.cpp)
set_property(TARGET harptuner PROPERTY CXX_STANDARD 11)
target_link_libraries(harptuner lionss pthread)

add_executable(erasure104 src/erasure104.cpp)
set_property(TARGET erasure104 PROPERTY CXX_STANDARD 11)
target_link_libraries(erasure104 lionss pthread)

add_executable(petalmap src/petalmap.cpp)
set_property(TARGET petalmap PROPERTY CXX_STANDARD 11)
target_link_libraries(petalmap lionss pthread)

add_executable(bluejay src/bluejay.cpp)
set_property(TARGET bluejay PROPERTY CXX_STANDARD 11)
target_link_libraries(bluejay lionss pthread)

