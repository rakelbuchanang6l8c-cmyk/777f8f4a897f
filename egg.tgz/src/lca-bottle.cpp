// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cradle-to-gate impact\n", stdout);
  return lionss_run_workload("lca-bottle");
}
