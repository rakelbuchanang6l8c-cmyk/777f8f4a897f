// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Diff nightly regression results"); }
int main(){
  announce();
  return lionss_run_workload("proj_lantern");
}
