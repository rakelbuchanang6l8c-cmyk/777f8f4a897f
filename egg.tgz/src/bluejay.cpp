// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lattice-Boltzmann channel flow"); }
int main(){
  announce();
  return lionss_run_workload("bluejay");
}
