// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Predict structure, 3 recycles"); }
int main(){
  announce();
  return lionss_run_workload("foldtiny");
}
