// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Invert for slip distribution\n", stdout);
  return lionss_run_workload("saffron");
}
