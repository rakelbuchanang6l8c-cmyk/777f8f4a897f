// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Top paths by p95 latency"); }
int main(){
  announce();
  return lionss_run_workload("logchew");
}
