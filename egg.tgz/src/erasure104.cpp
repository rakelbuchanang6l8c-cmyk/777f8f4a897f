// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode 4 parity, lose 3, recover\n", stdout);
  return lionss_run_workload("erasure104");
}
