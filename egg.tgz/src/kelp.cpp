// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Extract totals and VAT id\n", stdout);
  return lionss_run_workload("kelp");
}
