// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Single-flight under 2k rps");
  std::fflush(stdout);
  return lionss_run_workload("cache_stampede");
}
