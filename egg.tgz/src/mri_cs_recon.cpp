// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compressed-sensing recon, 30 iters"); }
int main(){
  announce();
  return lionss_run_workload("mri_cs_recon");
}
