// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sweep 800-1000 MHz"); }
int main(){
  announce();
  return lionss_run_workload("antennaDipole");
}
