// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render loom draft to SVG\n", stdout);
  return lionss_run_workload("loomsong");
}
