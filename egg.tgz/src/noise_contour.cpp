// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("DNL 65 contour"); }
int main(){
  announce();
  return lionss_run_workload("noise_contour");
}
