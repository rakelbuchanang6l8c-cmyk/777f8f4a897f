// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compute affected packages\n", stdout);
  return lionss_run_workload("monorepo-affected");
}
